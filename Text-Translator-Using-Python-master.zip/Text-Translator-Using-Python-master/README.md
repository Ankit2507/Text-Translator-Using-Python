# Text-Translator-Using-Python


## Steps to run this project.

> Create virtual env using this command `python -m venv venv`

> activate virtual env using this command `venv\Scripts\activate` for windows

> activate virtual env using this command `source venv/bin/activate` for linux

> clone the project 

## Goto the folder run this command `pip install -r requirements.txt` it will install all required libraries

## Then run the `translator.py` file
